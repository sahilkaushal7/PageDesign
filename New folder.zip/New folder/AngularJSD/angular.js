var myApp = angular.module("myModule",["ngRoute"])
	.config(function($routeProvider)
	{
		$routeProvider
		.when("/home",{
			templateUrl : "new/home.html",
			controller : "myController"
		})
		.when("/office",{
			templateUrl : "new/office.html",
			controller : "myOffice"
		})
		.when("/park",{
			templateUrl : "new/park.html",
			controller : "myPark"
		})
	})
	.controller("myController",function ($scope) {
		$scope.message = "Home";
	})
	.controller("myOffice",function ($scope) {
		$scope.message = "Office";
	})
	.controller("myPark",function ($scope) {
		$scope.message = "Park";
	});