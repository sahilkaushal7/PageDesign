  $(document).ready(function(){ $("#Rectangle-3").hide();$("#dates").hide();$("#saved-location").hide();});
            $(document).ready(function(){
                $("#Cross").click(function(){
                    $("#Rectangle-3").show();
                    $("#HSR").hide();
                });
            });
            $(document).ready(function(){
                $("#Rectangle-271").click(function(){
                    $("#Rectangle-3").hide();
                    $("#HSR").show();
                });
            });
            $(document).ready(function(){
                $("#locationTextField").focusin(function(){
                    $("#saved-location").show();
                });
                $("#locationTextField").focusout(function(){
                    $("#saved-location").hide();
                });
            });
            $(document).ready(function(){
                $("#main1").click(function(){
                    $("#categories").toggle();
                    $("#Rectangle-3").hide();
                     $("#HSR").toggle();
                    $("#dates").toggle();
                    $("#angle_down").toggleClass('angle_up');
                    $("#angle_down").toggleClass('angle_down');
                    
                });
            });
            
            function blurIt(val){
                if (val) {
				document.body.style.background = "rgba(0, 0, 0, 0.2)";
				}
                else document.body.style.background = "#f1f5f9";
            }
            function init() {
                var input = document.getElementById('locationTextField');
                var autocomplete = new google.maps.places.Autocomplete(input);
            }
 
            google.maps.event.addDomListener(window, 'load', init);